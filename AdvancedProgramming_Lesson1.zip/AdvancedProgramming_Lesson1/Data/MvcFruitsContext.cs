﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcFruitsContext : DbContext
    {
        public MvcFruitsContext(DbContextOptions<MvcFruitsContext> options)
        : base(options)
        {
        }
        public DbSet<Fruits> Fruits { get; set; }
    }
}
