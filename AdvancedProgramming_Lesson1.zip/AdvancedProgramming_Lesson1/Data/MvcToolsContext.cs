﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcToolsContext : DbContext
    {
        public MvcToolsContext(DbContextOptions<MvcToolsContext> options)
        : base(options)
        {
        }
        public DbSet<Tools> Tools { get; set; }
    }
}
