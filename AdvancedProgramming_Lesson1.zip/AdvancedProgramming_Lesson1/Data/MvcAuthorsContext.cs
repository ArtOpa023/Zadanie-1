﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcAuthorsContext : DbContext
    {
        public MvcAuthorsContext(DbContextOptions<MvcAuthorsContext> options)
        : base(options)
        {
        }
        public DbSet<Authors> Authors { get; set; }
    }
}
