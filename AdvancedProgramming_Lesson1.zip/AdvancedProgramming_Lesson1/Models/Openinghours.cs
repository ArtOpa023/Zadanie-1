﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson1.Models
{
    public class Openinghours
    {
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }
        [Display(Name = "Dzień tygodnia")]
        public string Weekday { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Godzina otwarcia")]
        public DateTime OpeningTime { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Godzina zamknięcia")]
        public DateTime ClosingTime { get; set; }


        [Display(Name = "Czas trwania otwarcia")]
        public int  Duration { get; set; }
        [Display(Name = "Liczba osób odwiedzająca bibliotekę")]
        public int People { get; set; }
    }
}
