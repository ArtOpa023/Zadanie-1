﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson1.Models
{
    public class Literarygeneres
    { 
        [Display(Name = "Identyfikator")]
        public int Id { get; set; }
        [Display(Name = "Nazwa gatunku")]
        public string Name { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Data powstania gatunku")]
        public DateTime InceptionDate { get; set; }
        [Display(Name = "Główne motywy występujące w gatunku")]
        public string Motives { get; set; }
        [Display(Name = "Populatność gatunku")]
        public string Popularity { get; set; }
        [Display(Name = "Liczba książek w danym gatunku")]
        public int Books { get; set; }
    }
}
