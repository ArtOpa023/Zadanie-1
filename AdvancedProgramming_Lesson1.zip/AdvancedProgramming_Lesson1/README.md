# How to run

To run compile and the in Tools -> Nuget Package Manager Console issue the following:

```
Update-Database
```

# Last modified
2023/03/22
